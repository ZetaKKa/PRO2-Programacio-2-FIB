/** @file Cjt_Mensaje.hh
    @brief Especificación de la clase Cjt_Mensaje
*/

#ifndef _CJT_MENSAJE_HH_
#define _CJT_MENSAJE_HH_

#ifndef NO_DIAGRAM
#include<iostream>
#include <map>
using namespace std;
#endif


/** @class Cjt_Mensaje
    @brief Representa un diccionario de mensajes

    Dispone de dos estados posibles (inicializado / no inicializado); si está inicializado tiene M mensajes; si no está inicializado no contiene ningun mensaje y solo se puede inicializar

    */

class Cjt_Mensaje
  {

public:
    
  //Constructoras

  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un Cjt_Mensaje.
      
      \pre <em>cierto</em>
      \post El resultado es un Cjt_Mensaje no inicializado
      
  */
  
  Cjt_Mensaje();

  //Modificadoras

  /** @brief Realiza una lectura de los M mensajes con su identificador

      Representa que se leen todos los mensajes con identificador del canal de entrada 
      
      \pre <em>cierto</em>
      \post Mensajes del canal de entrada leídos
      
  */
  
  void leer_mensajes();

  /** @brief Añade un mensaje al diccionario de mensajes
      
      \pre El parámetro implícito (M) está inicializado
      \post El parámetro implícito aumenta en 1
      
  */
  
  void nuevo_mensaje(const string& idm, const string& mensaje);

  /** @brief Elimina un mensaje del diccionario de mensajes
   * 
      \pre El parámetro implícito (M) está inicializado
      \post El parámetro implícito disminuye en 1
      
  */
  
  void borra_mensaje(const string& idm);

  // Consultoras

  /** @brief Consultora del tamaño del diccionario de mensajes

      \pre El parámetro implícito está inicializado
      \post El resultado es el tamaño del diccioanrio de mensajes
      
  */
  int consultar_tamano() const;

  /** @brief Consultora de un mensaje concreto

      \pre El parámetro implícito está inicializado
      \post El resultado es el identificador de un mensaje concreto
      
  */

  string consultar_mensaje(const string& idm) const;
  
  /** @brief Consultora si existe o no un mensaje concreto

      \pre El parámetro implícito está inicializado
      \post El resultado es cierto si existe o false si no existe un mensaje concreto
      
  */
  
  bool existe_mensaje(const string& idm) const;
  
  // Escritura del Cjt_Mensaje

  /** @brief Operación de escritura

      \pre El parámetro implícito está inicializado
      \post Escribe las propiedades y el contenido del parámetro implícito por el canal estándar de salida
      
  */
  
  void listar_mensajes() const;

private: 
    
    /**@brief Diccionario de mensajes; el primer parámetro es el identificador y el segundo parámetro es el mesnaje*/
    
    map<string,string> Mensajes;
    
};
#endif
