/** @file Rejilla.hh
    @brief Especificación de la clase Rejilla
*/

#ifndef _REJILLA_HH_
#define _REJILLA_HH_

#ifndef NO_DIAGRAM
#include <iostream>
#include<vector>
#include <algorithm>
using namespace std;
#endif

/** @class Rejilla
    @brief Representa una Rejilla

    Dispone de dos estados posibles (inicializada / no inicializada); si está inicializada tiene, dimension n y longitud k; si no está inicializada no contiene nada y solo se puede inicializar
    
    */
    
class Rejilla 
  {
    
public:
    
  //Constructoras
    
  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar una rejilla.
      
      \pre <em>cierto</em>
      \post El resultado es una rejilla no inicializada
      
  */  
  
  Rejilla();
  
  //Modificadoras
  
  /** @brief Realiza una lectura de la rejilla

      Representa que se lee la rejilla del canal de entrada 
      
      \pre Los parámetros n y k están inicializados 
      \post Los parámetros n y k configuran la dimension y longitud de la rejilla, se construye la rejilla 4*k
      
  */
  
  void leer_rejilla(int n, int k);
  
  /** @brief Lee y codifica un mensaje mediante la rejilla con el idr

      Representa que se lee y codifica el mensaje 
      
      \pre El parámetro implícito está inicializado, el parámetro input está inicializado
      \post El parámetro output contiene el mensaje input codificado
      
  */   
  
  void codificar_rejilla (const string& input, string& output);
  
  /** @brief Lee y decodifica un mensaje mediante la rejilla con el idr

      Representa que se lee y decodifica el mensaje
      
      \pre El parámetro implícito está inicializado, el parámetro input está inicializado
      \post El parámetro output contiene el mensaje input decodificado
      
  */
  
  void decodificar_rejilla(const string& input, string& output);
  
  //Consultores
    
     /** @brief Consultora de la dimension de una rejilla concreta

      \pre El parámetro implícito está inicializado
      \post El resultado es la dimension de una rejilla concreta
      
  */
     
  int consultar_dimension() const;

  /** @brief Consultora de la longitud de una rejilla concreta

      \pre El parámetro implícito está inicializado
      \post El resultado es la longitud de una rejilla concreta
      
  */
  
  int consultar_longitud() const;
  
  /** @brief Consultora de si una rejilla concreta es valida o no

      \pre El parámetro implícito está inicializado
      \post El resultado es true si la rejilla es valida o false si no es valida la rejilla concreta
      
  */
  
  bool rejilla_valida() const;
    
  // Escritura de la Rejilla

  /** @brief Operación de escritura

      \pre El parámetro implícito está inicializado
      \post Escribe las propiedades y el contenido del parámetro implícito por el canal estándar de salida
      
  */
  
  void listar_Rejilla() const;

private:
  
  /**@brief Dimensión y longitud de la Rejilla*/
  
  int n, k;

  /**@brief Vector de pairs enteros, cada pair es una posicon [fila,columna] de la rejilla 4k, pair.first representa la fila y pair.second representa la columna*/
  
  vector< pair<int,int> > Rj;
  
};
#endif
