/** @file Cjt_Patron.cc
    @brief Código de la clase Cjt_Patron
*/

#include "Cjt_Patron.hh"

Cjt_Patron::Cjt_Patron() {}

void Cjt_Patron::leer_patrones () {
    int P;
    cin >> P;
    for (int i = 0; i < P; ++i) {
        Patron pat;
        pat.leer_patron();
        
        Patrones.push_back(pat);
    }
}

void Cjt_Patron::nuevo_patron () {
    Patron pat;
    pat.leer_patron();
    Patrones.push_back(pat);
}
  
void Cjt_Patron::codificar_patron (int idp, int b, const string& input, string& output) {
    Patrones[idp-1].codificar_patron(b,input,output);
}

void Cjt_Patron::decodificar_patron(int idp, int b, const string& input, string& output) {
    Patrones[idp-1].decodificar_patron(b,input,output);
}

int Cjt_Patron::consultar_tamano() const {
    return Patrones.size();
}

bool Cjt_Patron::existe_patron(const int& idp) const {
    return idp > 0 and idp <= Patrones.size();
    
}

void Cjt_Patron::listar_patrones() const {
    for (int i = 0; i < Patrones.size(); ++i) {
        cout << "Patron " << i+1 << ':' << endl;
        Patrones[i].listar_Patron();
    }
}

