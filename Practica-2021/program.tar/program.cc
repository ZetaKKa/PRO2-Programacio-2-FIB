/**
 * @mainpage Encriptación de mensajes.
                
    En program.cc encontramos el programa principal para la encriptación de mensajes.
    Podemos encriptar cualquier mensaje del módulo conjunto de mensajes (Cjt_Mensaje)
    mediante 2 métodos, con rejillas seleccionadas del módulo conjunto de rejillas (Cjt_Rejilla)
    donde se selecciona una rejilla del módulo rejilla (Rejilla) o bien, mediante patrones del módulo
    conjunto de patrones (Cjt_Patron) donde se selecciona un patrón del módulo patrón (Patron).
                
*/

/** @file program.cc
    @brief Programa principal para <em>Encriptación de mensajes</em>.
*/

#include "Cjt_Mensaje.hh"
#include "Cjt_Rejilla.hh"
#include "Cjt_Patron.hh"
#include "Rejilla.hh"
#include "Patron.hh"

/** @brief Programa principal para <em>Encrpitación de mensajes</em>.
*/

int main ()
{
    Cjt_Mensaje m;
    m.leer_mensajes();
    
    Cjt_Rejilla r;
    r.leer_rejillas();
    
    Cjt_Patron p;
    p.leer_patrones();
    
    //comandos, mensaje a leer, s: terminar lecturas con getline();
    string comando, input, s;
    cin >> comando;
    
    //identificadores
    int idr, idp;

    //mensaje
    string idm, mensaje;
    //rejilla
    Rejilla rej;
    //patron
    Patron pat;
    int b;
    
    while (comando != "fin") {
        
        //nuevo_mensaje
        if (comando == "nm" or comando == "nuevo_mensaje") {
            getline(cin,s);
            cin >> idm;
            getline(cin,s);
            getline(cin,mensaje);
            
            cout << '#' << comando << ' ' << idm << endl;
            
            if (m.existe_mensaje(idm)) cout << "error: ya existe un mensaje con ese identificador";
            else {
                m.nuevo_mensaje(idm,mensaje);
                cout  << m.consultar_tamano();
            }
            cout << endl;
        }
        //nueva_rejilla
        else if (comando == "nr" or comando == "nueva_rejilla") {
            cout << '#' << comando << endl;
            r.nueva_rejilla();
        }
        //nuevo_patron
        else if (comando == "np" or comando == "nuevo_patron") {
            p.nuevo_patron();
            cout << '#' << comando << endl << p.consultar_tamano() << endl;
        }
        //borra_mensaje
        else if (comando == "bm" or comando == "borra_mensaje") {
            cin >> idm;
            
            cout << '#' << comando << ' ' << idm << endl;
            
            if (not m.existe_mensaje(idm)) cout << "error: el mensaje no existe";
            else {
                m.borra_mensaje(idm);
                cout << m.consultar_tamano();
            }
            cout << endl;
        }
        //listar_mensajes
        else if (comando == "lm" or comando == "listar_mensajes") {
            cout << '#' << comando << endl;
            m.listar_mensajes();
        }
        //listar_rejillas
        else if (comando == "lr" or comando == "listar_rejillas") {
            cout << '#' << comando << endl;
            r.listar_rejillas();
        }
        //listar_patrones
        else if (comando == "lp" or comando == "listar_patrones") {
            cout << '#' << comando << endl;
            p.listar_patrones();
        }
        //codificar_rejilla
        else if (comando == "cr" or comando == "codificar_rejilla") {
            cin >> idr;
            getline(cin,input);
            getline(cin,input);
            
            cout << '#' << comando << ' ' << idr << endl;
            
            if (not r.existe_rejilla(idr)) cout << "error: la rejilla no existe";
            else {
                string output;
                r.codificar_rejilla(idr,input,output);
                cout << '"' << output << '"';
            }
            cout << endl;
        }
        //codificar_guardado_rejilla
        else if (comando == "cgr" or comando == "codificar_guardado_rejilla") {
            cin >> idm >> idr;
            
            cout << '#' << comando << ' ' << idm << ' ' << idr << endl;
            
            if (not m.existe_mensaje(idm)) cout << "error: el mensaje no existe"; 
            else if (not r.existe_rejilla(idr)) cout << "error: la rejilla no existe"; 
            else {
                string output;
                r.codificar_rejilla(idr,m.consultar_mensaje(idm),output);
                cout << '"' << output << '"';
            }
            cout << endl;
        }
        //decodificar_rejilla
        else if (comando == "dr" or comando == "decodificar_rejilla") {
            cin >> idr;
            getline(cin,input);
            getline(cin,input);
            
            cout << '#' << comando << ' ' << idr << endl;
            
            string output;
            if (not r.existe_rejilla(idr)) cout << "error: la rejilla no existe" << endl;
            else r.decodificar_rejilla(idr,input,output);
        }
        //codificar_patron
        else if (comando == "cp" or comando == "codificar_patron") {
            cin >> idp >> b;
            
            getline(cin,s);
            getline(cin,input);
            
            cout << '#' << comando << ' ' << idp << ' ' << b << endl;
            
            if (not p.existe_patron(idp)) cout << "error: el patron no existe";
            else {
                string output;
                p.codificar_patron(idp,b,input,output);
                cout << '"' << output << '"';
            }
            cout << endl;
        }
        //codificar_guardado_patron
        else if (comando == "cgp" or comando == "codificar_guardado_patron") {
            cin >> idm >> idp >> b;
            
            cout << '#' << comando << ' ' << idm << ' ' << idp << ' ' << b << endl;
            
            if (not m.existe_mensaje(idm)) cout << "error: el mensaje no existe"; 
            else if (not p.existe_patron(idp)) cout << "error: el patron no existe"; 
            else {
                string output;
                p.codificar_patron(idp,b,m.consultar_mensaje(idm),output);
                cout << '"' << output << '"';
            }
            cout << endl;
        }
        //decodificar_patron
        else if (comando == "dp" or comando == "decodificar_patron") {
            cin >> idp >> b;
            getline(cin,s);
            getline(cin,input);
            
            cout << '#' << comando << ' ' << idp << ' ' << b << endl;
            
            if (not p.existe_patron(idp)) cout << "error: el patron no existe";
            else {
                string output;
                p.decodificar_patron(idp,b,input,output);
                cout << '"' << output << '"';
            }
            cout << endl;
        }
        cin >> comando;        
    }
}
