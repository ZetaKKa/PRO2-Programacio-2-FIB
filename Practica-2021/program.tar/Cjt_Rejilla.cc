/** @file Cjt_Rejilla.cc
    @brief Código de la clase Cjt_Rejilla
*/

#include "Cjt_Rejilla.hh"

Cjt_Rejilla::Cjt_Rejilla() {}

void Cjt_Rejilla::leer_rejillas() {
    int R;
    cin >> R;
    for (int i = 0; i < R; ++i) {
        int n , k;
        Rejilla rej;
        cin >> n >> k;
        rej.leer_rejilla(n,k);
        
        Rejillas.push_back(rej);
    }
}
 
void Cjt_Rejilla::nueva_rejilla() {
    int n, k;
    cin >> n >> k;
    
    if (4*k != (n*n)) {
        //leer posiciones aunque sea no valida
        string s;
        getline(cin,s);
        cout << "error: dimensiones incorrectas de la rejilla";
    }
    else {
        Rejilla rej;
        rej.leer_rejilla(n,k);
        if (not rej.rejilla_valida()) {
            cout << "error: la rejilla con sus giros no cubre todas las posiciones N x N";
        }
        else {
            Rejillas.push_back(rej);
            cout << Cjt_Rejilla::consultar_tamano();
        }
    }
    cout << endl;
}

void Cjt_Rejilla::codificar_rejilla (int idr, const string& input, string& output) {
    Rejillas[idr-1].codificar_rejilla(input,output);
}

void Cjt_Rejilla::decodificar_rejilla(int idr, const string& input, string& output) {
    int x = Rejillas[idr-1].consultar_dimension()*Rejillas[idr-1].consultar_dimension();
    if (input.size()%x != 0) cout << "error: la dimension del mensaje es inadecuada para la rejilla";
    else {
        Rejillas[idr-1].decodificar_rejilla(input,output);
        cout << '"' << output << '"';
    }
    cout << endl;
}

int Cjt_Rejilla::consultar_tamano() const {
    return Rejillas.size();
}

bool Cjt_Rejilla::existe_rejilla(const int& idr) const {
    return idr > 0 and idr <= Rejillas.size();
}

void Cjt_Rejilla::listar_rejillas() const {
    for (int i = 0; i < Rejillas.size(); ++i) {
        cout << "Rejilla " << i+1 << ':' << endl;
        Rejillas[i].listar_Rejilla();
    }
}
