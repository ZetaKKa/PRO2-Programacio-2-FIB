/** @file Patron.hh
    @brief Especificación de la clase Patron
*/

#ifndef _PATRON_HH_
#define _PATRON_HH_



#ifndef NO_DIAGRAM
#include "BinTree.hh"
#include<iostream>
#include<vector>
#include <algorithm>
#include <queue>
using namespace std;
#endif

/** @class Patron
    @brief Representa un Patron

    Dispone de dos estados posibles (inicializado / no inicializado); si está inicializado contiene naturales; si no está inicializado no contiene nada y solo se puede inicializar

    */

class Patron
  {
    
public:
    
  //Constructoras
    
  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un Patron
      
      \pre <em>cierto</em>
      \post El resultado es un patron no inicializado
  */ 
  
  Patron();
  
  //Modificadoras
  
  /** @brief Realiza una lectura del Patron

      Representa que se lee el patron del canal de entrada 
      
      \pre <em>cierto</em>
      \post Patron leído del canal de entrada
      
  */
  
  void leer_patron();
  
  //Consultores
  
  /** @brief Lee y codifica un mensaje dividiendo el mensaje en bloques de tamaño b

      Representa que se lee y codifica el mensaje 
      
      \pre El parámetro implícito está inicializado, el parámetro b está inicializado, el parámetro input está inicializado
      \post El parámetro output contiene el mensaje input decodificado en b bloques
      
  */   
  
  void codificar_patron (int b, const string& input, string& output);
  
  /** @brief Lee y decodifica un mensaje dividiendo el mensaje en bloques de tamaño b

      Representa que se lee y decodifica el mensaje
      
      \pre El parámetro implícito está inicializado, el parámetro input está inicializado
      \post El parámetro output contiene el mensaje input decodificado
      
  */
  
  void decodificar_patron(int b, const string& input, string& output);
  
  /** @brief Consultora del tamaño de un patron concreto

      \pre El parámetro implícito está inicializado
      \post El resultado es la dimension de un patron concreto
      
  */
  
  int consultar_tamano() const;

  // Escritura del Patron

  /** @brief Operación de escritura

      \pre El parámetro implícito está inicializado
      \post Escribe las propiedades y el contenido del parámetro implícito por el canal estándar de salida
  */
  
  void listar_Patron() const;

private:
 
  /**@brief Arbol patron*/
    
  BinTree<int> arbolpatrones;
  
  /**@brief Lee una secuencia de enteros con marca -1 y los configura en forma de arbol en preorden
     
     \pre a es vacío; el canal estandar de entrada contiene el recorrido en preorden de un arbol binario A de enteros
     \post a = A
     
   */
  
  static void read_bintree_int(BinTree<int>& a,int marca);
  
  /**@brief Convierte un string a arbol
     
     \pre El parámetro input ya esta inicializado
     \post Devuelve un arbol de enteros que contiene el string
     
   */
  
  static BinTree<int> string_to_bintree(const string& input);
  
  /**@brief Construye recursivamente el arbolmensaje mediante el string input
     
     \pre El arbol a está vacío; el mensaje input ya esta inicializado y el parámetro i ya está inicializado
     \post Retorna un arbolmensaje de enteros que contiene el mensaje recorrido recursivamente mediante el parámetro i
     
   */
  
  static BinTree<int> imm_string_to_bintree(BinTree<int>& a, const string& input, int i);
  
  /**@brief Convierte un arbol a string
     
     \pre a es un arbol inicializado
     \post un string que contiene todos los elementos del arbol en amplada
     
   */
  
  static string bintree_to_string(const BinTree<int>& a); 
  
    /**@brief Construye recursivamente el arbol mosaico (que es identico a arbolmensaje, aunque solo nos interesa su tamaño) a partir del arbolpatrones pat (que nos sirve para descomponer el arbolpatrones) y el arbolpatrones pat_inm (que nos sirve para volver a empezar el arbolpatrones desde su inicio) 
     
     \pre arbolmos ya esta inicializado aunque cambiaran todos sus valores, pat ya esta inicializado con arbolpatrones, pat_inmovil ya esta inicializado con arbolpatrones
     \post arbolmos es un arbol con tamaño arbolmensaje y lleno de arbolpatrones
     
   */
  
  static void arbol_mosaico(BinTree<int>& arbolmos, const BinTree<int>& pat, const BinTree<int>& pat_inm);
  
    /**@brief Realiza el proceso de encriptacion mediante el parámetro accion se decidie si se trata de codificación ('c') o de decodificación ('d')
              Construye el arbolmensaje a partir del string sub, construye el arbolmosaico y finalmente codifica o decodifica convirtiendo el arbolmensaje y el arbolmosaico a strings
     
     \pre El string sub ya esta inicializado y contiene el mensaje a tratar, el string output solo es vacío en la primera llamada, el char accion ya esta inicializado
     \post Output contiene la codificación o decodificación de sub
     
   */
  
  void encriptacion_por_arboles(const string& sub, string& output, char accion);
  
  
  /**@brief Operación de escritura
     
     \pre El parámetro implícito está inicializado
     \post Escribe las propiedades y el contenido del parámetro implícito por el canal estándar de salida recursivamente
     
   */
  
  static void listar(const BinTree<int>& a); 
 

};
#endif
