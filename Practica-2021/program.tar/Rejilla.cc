/** @file Rejilla.cc
    @brief Código de la clase Rejilla
*/

#include "Rejilla.hh"

Rejilla::Rejilla(){}

void Rejilla::leer_rejilla(int n, int k) {
    this->n = n;
    this->k = k;
    
    for (int i = 0; i < k; ++i) {
        pair<int,int> ij;
        cin >> ij.first >> ij.second;
        
        Rj.push_back(make_pair(ij.first,ij.second));
    }

    int I = 0;
    for (int i = k; i < 4*k; ++i) {
        int x = n+1-this->Rj[I].second;
        int y = this->Rj[I].first;
        
        Rj.push_back(make_pair(x,y));
        I++;
    }
    sort(Rj.begin(),Rj.begin()+k);          //1ra fila
    sort(Rj.begin()+k,Rj.begin()+2*k);      //2na fila
    sort(Rj.begin()+2*k,Rj.begin()+3*k);    //3ra fila
    sort(Rj.begin()+3*k,Rj.end());          //4ta fila
}

void Rejilla::codificar_rejilla (const string& input, string& output) {
    int dimension = this->n*this->n;
    int longitud = input.size();
    
    int blokes;
    if (longitud%dimension == 0) blokes = longitud/dimension;
    else blokes = longitud/dimension +1;
    
    vector < vector<char> > mat(this->n+1,vector<char>(this->n+1));     //matriz n*n
    
    int y = 0;
    for (int i = 0; i < blokes; ++i) {
        //llenar matriz n*n con coordenadas de vector 4k
        for (int x = 0; x < 4*this->k; ++x) {
            if (y < longitud) mat[this->Rj[x].first-1][this->Rj[x].second-1] = input[y];
            else mat[this->Rj[x].first-1][this->Rj[x].second-1] = ' ';
            ++y;
        }
        //construir el output con matriz n*n
        for (int f = 0; f < this->n; ++f) {
            for (int c = 0; c < this->n; ++c) {
                output += mat[f][c];
            }
        }
    }
}
  
void Rejilla::decodificar_rejilla(const string& input, string& output) {
    int longitud = input.size();
    int dimension = this->n*this->n;
    int blokes;
    
    if (longitud%dimension == 0) blokes = longitud/dimension;
    else blokes = longitud/dimension +1;
    
    vector < vector<char> > mat(this->n+1,vector<char>(this->n+1));     //matriz n*n

    int y = 0;
    for (int i = 0; i < blokes; ++i) {
        //llenar matriz n*n
        for (int f = 0; f < this->n; ++f) {
            for (int c = 0; c < this->n; ++c) {
                if (y < longitud) mat[f][c] = input[y];
                else mat[f][c] = ' ';
                ++y;
            }
        }
        //construir el output con matriz n*n con coordenadas de vector 4k
        for (int x = 0; x < 4*this->k; ++x) {
            output += mat[this->Rj[x].first-1][this->Rj[x].second-1];
        }
    }
}

int Rejilla::consultar_dimension() const {
    return n;
}

int Rejilla::consultar_longitud() const {
    return k;
}

bool Rejilla::rejilla_valida() const {
    vector < vector < char > > mat(this->n+1, vector< char > (this->n+1));      //matriz n*n

    for (int x = 0; x < 4*this->k; ++x) {
        if (mat[this->Rj[x].first][this->Rj[x].second] != 'x') mat[this->Rj[x].first][this->Rj[x].second] = 'x';
        else return false;
    }
    return true;
}  

void Rejilla::listar_Rejilla() const {
    cout << this->n << ' ' << this->k << endl;
    
    for (int i = 0; i < 4*this->k; i++) {
        if (i == this->k-1 or i == this->k*2-1 or i == this->k*3-1 or i == this->k*4-1) cout << '(' << this->Rj[i].first << ',' << this->Rj[i].second << ')' << endl;   //para endl
        else cout << '(' << this->Rj[i].first << ',' << this->Rj[i].second << ')' << ' '; 
    }
}
