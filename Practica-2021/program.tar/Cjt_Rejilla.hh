/** @file Cjt_Rejilla.hh
    @brief Especificación de la clase Cjt_Rejilla
*/

#ifndef _CJT_REJILLA_HH_
#define _CJT_REJILLA_HH_

#include "Rejilla.hh"

/** @class Cjt_Rejilla
    @brief Representa un conjunto de rejillas

    Dispone de dos estados posibles (inicializado / no inicializado); si está inicializado tiene R rejillas; si no está inicializado no contiene nada y solo se puede inicializar

    */

class Cjt_Rejilla
  {

public:
    
  //Constructoras

  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un conjunto rejillas.
      
      \pre <em>cierto</em>
      \post El resultado es un conjunto de rejillas no inicializado
      
  */
  
  Cjt_Rejilla();

  //Modificadoras

  /** @brief Realiza una lectura de las R rejillas con sus dimensiones y longitudes

      Representa que se leen todas las rejillas del canal de entrada 
      
      \pre <em>cierto</em>
      \post Rejillas del canal de entrada leídas
      
  */
  
 void leer_rejillas ();

  /** @brief Añade una rejilla al vector de rejillas comprobando su validez
      
      \pre El parámetro implícito (R) está inicializado
      \post El parámetro implícito aumenta en 1
      
  */
  
  void nueva_rejilla();
  
  // Consultoras
  
  /** @brief Lee y codifica un mensaje mediante la rejilla con su identificador
   * 
      Representa que se lee y codifica el mensaje
      
      \pre El parámetro implícito (R) está inicializado, idr está inicializado y input está inicializado
      \post El parámetro output contiene la codificación del mensaje input con rejilla idr
      
  */
  
  void codificar_rejilla (int idr, const string& input, string& output);
  
  /** @brief Lee y decodifica un mensaje mediante la rejilla con el idr

      Representa que se lee y decodifica el mensaje
      
      \pre El parámetro implícito (R) está inicializado, idr está inicializado y input está inicializado
      \post El parámetro output contiene la decodifcación del mensaje input con rejilla idr
      
  */
  
  void decodificar_rejilla(int idr, const string& input, string& output);
  
  /** @brief Consultora del tamaño del vector de rejillas

      \pre El parámetro implícito está inicializado
      \post El resultado es el tamaño del vector de rejillas
  */
  
  int consultar_tamano() const;

  /** @brief Consultora si existe o no una rejilla concreta

      \pre El parámetro implícito está inicializado
      \post El resultado es true si existe o false si no existe una rejilla concreta
  */
  
  bool existe_rejilla(const int& idr) const;

  // Escritura del Cjt_Rejilla

  /** @brief Operación de escritura

      \pre El parámetro implícito está inicializado
      \post Escribe las propiedades y el contenido del parámetro implícito por el canal estándar de salida
      
  */
  
  void listar_rejillas() const;

private: 
  
  /**@brief Vector de Rejillas donde cada posición 'i' del vector es el idr de la Rejilla y su contenido '[i]' es una Rejilla*/
  
  vector<Rejilla> Rejillas;
  
};
#endif
