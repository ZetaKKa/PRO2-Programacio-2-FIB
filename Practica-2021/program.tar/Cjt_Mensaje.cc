/** @file Cjt_Mensaje.cc
    @brief Código de la clase Cjt_Mensaje
*/

#include "Cjt_Mensaje.hh"

Cjt_Mensaje::Cjt_Mensaje() {}

void Cjt_Mensaje::leer_mensajes() {
    int M;
    cin >> M;
    string idm, mensaje;
    for (int i = 0; i < M; ++i) {
        cin >> idm;
        getline(cin,mensaje);   //lee de idm hasta mensaje
        getline(cin,mensaje);   //lee mensaje
        
        Mensajes.insert(make_pair(idm,mensaje));
    }
}

void Cjt_Mensaje::nuevo_mensaje(const string& idm, const string& mensaje) {
    Mensajes.insert(make_pair(idm,mensaje));
}

void Cjt_Mensaje::borra_mensaje(const string& idm) {
    Mensajes.erase(idm);
}

int Cjt_Mensaje::consultar_tamano() const {
    return Mensajes.size();
}

string Cjt_Mensaje::consultar_mensaje(const string& idm) const {
    map<string,string>::const_iterator it = Mensajes.find(idm);
    return it->second;
}

bool Cjt_Mensaje::existe_mensaje(const string& idm) const {
    map<string,string>::const_iterator it = Mensajes.find(idm);
    return it != Mensajes.end();
}

void Cjt_Mensaje::listar_mensajes() const {
    for (map<string,string>::const_iterator it = Mensajes.begin(); it != Mensajes.end(); ++it) {
        cout << it->first << endl << '"' << it->second << '"' << endl;
    }
}
