/** @file Cjt_Patron.hh
    @brief Especificación de la clase Cjt_Patron
*/

#ifndef _CJT_PATRON_HH_
#define _CJT_PATRON_HH_

#include "Patron.hh"

/** @class Cjt_Patron
    @brief Representa un conjunto de patrones

    Dispone de dos estados posibles (inicializado / no inicializado); si está inicializado tiene P patrones; si no está inicializado no contiene nada y solo se puede inicializar
    
    */

class Cjt_Patron
  {

public:
    
  //Constructoras

  /** @brief Creadora por defecto.

      Se ejecuta automáticamente al declarar un Cjt_Patron
      
      \pre <em>cierto</em>
      \post El resultado es un Cjt_Patron no inicializado
  */
  
  Cjt_Patron();

  //Modificadoras

  /** @brief Realiza una lectura de los P patrones y posiciones

      Representa que se leen todos los patrones del canal de entrada 
      
      \pre <em>cierto</em>
      \post Patrones del canal de entrada leídos
      
  */
  
 void leer_patrones ();

  /** 
      @brief Añade un patron al vector de patrones
      
      \pre El parámetro implícito (P) está inicializado
      \post El parámetro implícito aumenta en 1
      
  */
  
  void nuevo_patron ();
  
  //Consultoras
  
  /** @brief Lee y codifica un mensaje mediante el patron con el idp dividiendo el mensaje en bloques de tamaño b

      Representa que se lee y codifica el mensaje 
      
      \pre El parámetro implícito está inicializado, el parámetro idp está inicializao, el parámetro b está inicializado, el parámetro input está inicializado
      \post El parámetro output contiene el mensaje input codificado en b bloques mediante el patron idp
      
  */ 
  
  void codificar_patron (int idp, int b, const string& input, string& output);
  
  /** @brief Lee y decodifica un mensaje mediante el patron con el idp dividiendo el mensaje en bloques de tamaño b

      Representa que se lee y decodifica el mensaje
      
      \pre El parámetro implícito está inicializado, el parámetro idp está inicializao, el parámetro b está inicializado, el parámetro input está inicializado
      \post El parámetro output contiene el mensaje input decodificado en b bloques mediante el patron idp
      
  */
  
  void decodificar_patron(int idp, int b, const string& input, string& output);

  /** @brief Consultora del tamaño de la lista de patrones

      \pre El parámetro implícito está inicializado
      \post El resultado es el tamaño del vector patrones
      
  */
  
  int consultar_tamano() const;

  /** @brief Consultora si existe o no un patron concreto

      \pre El parámetro implícito está inicializado
      \post El resultado es true si existe o false si no existe un patron concreto
      
  */
  
  bool existe_patron(const int& idp) const;

  // Escritura de la Cjt_Patron

  /** @brief Operación de escritura

      \pre El parámetro implícito está inicializado
      \post Escribe las propiedades y el contenido del parámetro implícito por el canal estándar de salida
      
  */
  
  void listar_patrones() const;

private: 
    
  /**@brief Vector de Patrones donde cada posición 'i' del vector es el idp del Patron y su contenido '[i]' es un Patron*/
    
    vector<Patron> Patrones;
    
};
#endif
