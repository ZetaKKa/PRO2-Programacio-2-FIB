/** @file Patron.cc
    @brief Código de la clase Patron
*/

#include "Patron.hh"

Patron::Patron(){}

void Patron::read_bintree_int(BinTree<int>& a,int marca) {
    int x;
    cin >> x;
    if (x!=marca){
        BinTree<int> l;
        read_bintree_int(l,marca);
        BinTree<int> r;
        read_bintree_int(r,marca);
        
        a=BinTree<int>(x,l,r);
    }
}

void Patron::leer_patron() {
    BinTree<int> a;
    read_bintree_int(a,-1);
    this->arbolpatrones = a;
}

BinTree<int> Patron::imm_string_to_bintree(BinTree<int>& a, const string& input, int i) {
    if (i <= input.size()) {
        BinTree<int> l;
        BinTree<int> r;
        
        imm_string_to_bintree(l,input,2*i);
        imm_string_to_bintree(r,input,2*i+1);
        
        a = BinTree<int>(int(input[i-1]),l,r);
    }
    return a;
}

BinTree<int> Patron::string_to_bintree(const string& input) {
    BinTree<int> a;
    return imm_string_to_bintree(a,input,1);
}

string Patron::bintree_to_string(const BinTree<int>& a) {
    string out;
    if (not a.empty()) {
        queue< BinTree<int> > c;
        c.push(a);
        while (not c.empty()) {
            BinTree<int> aux = c.front();
            c.pop();
            out.push_back(aux.value());
            if (not aux.left().empty()) c.push(aux.left());
            if (not aux.right().empty()) c.push(aux.right());
        }
    }
    return out;
}

void Patron::arbol_mosaico(BinTree<int>& arbolmos, const BinTree<int>& pat, const BinTree<int>& pat_inm) {   
    if (not arbolmos.empty()) {
        BinTree<int> la = arbolmos.left();
        BinTree<int> ra = arbolmos.right();
        
        if (not pat.empty()) {
            arbol_mosaico(la,pat.left(),pat_inm);
            arbol_mosaico(ra,pat.right(),pat_inm);
            
            arbolmos = BinTree<int>(pat.value(),la,ra);
        }
        else {
            arbol_mosaico(arbolmos,pat_inm,pat_inm);    //para empezar de cero el patron
        }
    }
}

void Patron::encriptacion_por_arboles(const string& sub, string& output, char accion) {
    
    //////////////string->arbolmensaje\\\\\\\\\\\\\\\\\\\\\\\\\\/
    BinTree<int> arbolmsg = string_to_bintree(sub);       
    
    //////////////arbolpatron->arbolmosaico\\\\\\\\\\\\\\\\\\\\\/
    BinTree<int> arbolmos = arbolmsg;                     
    BinTree<int> pat = this->arbolpatrones;               
                
    arbol_mosaico(arbolmos,pat,pat);                      
        
    //////////////arbolmosaico + arbolmensaje->output\\\\\\\\\\\/
        
    string mosaico = bintree_to_string(arbolmos);  
    string mensaje = bintree_to_string(arbolmsg);
    
    for (int i = 0; i < mensaje.size(); ++i) {
        char c;
        if (accion == 'c') c = 32+(mensaje[i]+mosaico[i]-32)%95;    //codificacion
        else {                                                      //decodificacion
            c = mensaje[i]-mosaico[i]-32;
            if (c < 0) c = 32+c+95;
            else c = 32+c%95;
        }
        output.push_back(c);
    }
    
}

void Patron::codificar_patron (int b, const string& input, string& output) {
    int blokes;
    
    if (input.size()%b != 0) blokes = (input.size()/b)+1;
    else blokes = input.size()/b;
    
    for (int i = 0; i < blokes; i++) {
        //seleccion del mensaje por bloque
        string sub = input.substr(i*b,b);
        //construccion del arbol mensaje con sub, construccion de arbol mosaico con arbol patron, codifificacion de ambos en output
        encriptacion_por_arboles(sub,output,'c');   //'c' de codificacion
    }
}

void Patron::decodificar_patron(int b, const string& input, string& output) {
    int blokes;
    
    if (input.size()%b != 0) blokes = (input.size()/b)+1;
    else blokes = input.size()/b;
    
    for (int i = 0; i < blokes; i++) {
        //seleccion del mensaje por bloque
        string sub = input.substr(i*b,b);
        //construccion del arbol mensaje con sub, construccion de arbol mosaico con arbol patron, decodifificacion de ambos en output
        encriptacion_por_arboles(sub,output,'d');   //'d' de decodificacion
    }
}

void Patron::listar_Patron() const {
    listar(this->arbolpatrones);
    cout << endl;
}

void Patron::listar(const BinTree<int>& a) {
    //si arbre es buit escriu els 2 '(', sino el primer '(' i el valor, al final escriura ')' ultim cout 
    cout << '(';
    if (not a.empty()) {
        
        cout << a.value();
        
        listar(a.left());
        listar(a.right());
    }
    cout << ')';
}

